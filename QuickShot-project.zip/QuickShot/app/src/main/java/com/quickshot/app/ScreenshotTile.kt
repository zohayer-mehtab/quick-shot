package com.quickshot.app

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class ScreenshotTile : TileService() {

    override fun onStartListening() {
        qsTile?.apply {
            state = Tile.STATE_INACTIVE
            label = "Screenshot"
            updateTile()
        }
    }

    @Suppress("DEPRECATION")
    override fun onClick() {
        val service = ScreenshotService.instance
        if (service != null) {
            service.capture()
        } else {
            startActivityAndCollapse(
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}
