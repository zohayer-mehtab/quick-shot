package com.quickshot.app

import android.content.Context
import android.content.SharedPreferences

/** Single source of truth for volume-bar settings. Changes are observed live by ScreenshotService. */
object Prefs {
    private const val NAME = "quickshot"

    const val BAR_ON = "bar_on"          // Boolean, default true
    const val BAR_Y = "bar_y"            // Int, % of screen height from top, default 28
    const val BAR_LEN = "bar_len"        // Int, dp, 100..200 (200 dp = Android's gesture-exclusion budget per edge)
    const val BAR_ALPHA = "bar_alpha"    // Int, %, 5..40, default 10

    const val DEF_Y = 28
    const val DEF_LEN = 200
    const val DEF_ALPHA = 10

    fun of(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun isBarOn(context: Context): Boolean = of(context).getBoolean(BAR_ON, true)

    fun toggleBar(context: Context) {
        val p = of(context)
        p.edit().putBoolean(BAR_ON, !p.getBoolean(BAR_ON, true)).apply()
    }
}
