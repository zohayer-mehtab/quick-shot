package com.quickshot.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.media.AudioManager
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.roundToInt

/**
 * Vertical edge slider bound to STREAM_MUSIC. Drag or tap: top = max, bottom = 0.
 * Draws a translucent track (opacity = user setting, default 10%) with a hairline white
 * outline so it stays visible on both dark and light content.
 */
class VolumeBarView(
    context: Context,
    private val audio: AudioManager,
    private val onLabel: (String?) -> Unit
) : View(context) {

    private val stream = AudioManager.STREAM_MUSIC
    private val d = resources.displayMetrics.density

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = d
    }

    private val rect = RectF()
    private val fillRect = RectF()
    private val clip = Path()

    private var level = 0f   // 0..1, snapped to device volume steps

    /** Track opacity in percent (5..40). Fill is drawn at 2.5x the track opacity. */
    var opacityPercent: Int = Prefs.DEF_ALPHA
        set(value) {
            field = value
            invalidate()
        }

    fun syncFromSystem() {
        val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
        level = audio.getStreamVolume(stream).toFloat() / max
        invalidate()
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        // Stop the system back-swipe from stealing drags that start on the edge bar.
        systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t))
    }

    override fun onDraw(canvas: Canvas) {
        val a = opacityPercent / 100f
        val w = width.toFloat()
        val h = height.toFloat()
        val radius = w // large radius -> pill; left half is off-screen / clipped flush with the edge

        trackPaint.color = Color.argb((a * 255).roundToInt(), 0, 0, 0)
        fillPaint.color = Color.argb((minOf(1f, a * 2.5f) * 255).roundToInt(), 0, 0, 0)
        strokePaint.color = Color.argb((minOf(1f, a * 1.5f) * 255).roundToInt(), 255, 255, 255)

        rect.set(-radius, 0f, w - 1f, h)
        canvas.drawRoundRect(rect, radius / 2f, radius / 2f, trackPaint)

        val save = canvas.save()
        clip.reset()
        clip.addRoundRect(rect, radius / 2f, radius / 2f, Path.Direction.CW)
        canvas.clipPath(clip)
        fillRect.set(-radius, h * (1f - level), w, h)
        canvas.drawRect(fillRect, fillPaint)
        canvas.restoreToCount(save)

        canvas.drawRoundRect(rect, radius / 2f, radius / 2f, strokePaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                applyY(e.y)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onLabel(null)
        }
        return true
    }

    private fun applyY(y: Float) {
        val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
        val frac = 1f - (y / height.coerceAtLeast(1)).coerceIn(0f, 1f)
        val idx = (frac * max).roundToInt().coerceIn(0, max)
        if (idx != audio.getStreamVolume(stream)) {
            audio.setStreamVolume(stream, idx, 0)   // flags = 0: no system volume panel
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
        level = idx.toFloat() / max
        onLabel("${(idx * 100f / max).roundToInt()}%")
        invalidate()
    }
}
