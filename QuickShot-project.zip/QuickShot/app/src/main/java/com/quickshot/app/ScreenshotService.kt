package com.quickshot.app

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.TypedValue
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScreenshotService : AccessibilityService() {

    companion object {
        @Volatile var instance: ScreenshotService? = null
        const val ACTION_TOGGLE_BAR = "com.quickshot.app.TOGGLE_BAR"
        private const val CHANNEL_ID = "quickshot_capture"
        private const val NOTIF_ID = 1
        private const val BAR_WIDTH_DP = 24
        private const val VOLUME_CHANGED_ACTION = "android.media.VOLUME_CHANGED_ACTION"
    }

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private lateinit var prefs: SharedPreferences

    private var bar: VolumeBarView? = null
    private var barParams: WindowManager.LayoutParams? = null
    private var labelView: TextView? = null
    private var receiverRegistered = false
    private var listenerRegistered = false

    private val hideLabel = Runnable { removeLabel() }

    // Strong reference required: SharedPreferences holds listeners weakly.
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        handler.post {
            refreshBar()
            if (key == Prefs.BAR_ON) postNotification()
        }
    }

    // Keeps the bar in sync when volume changes by any other route (e.g. notification-panel slider).
    private val volumeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            bar?.syncFromSystem()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        // String lookup on purpose: AccessibilityService overrides it to return an overlay-capable WindowManager
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AudioManager::class.java)
        prefs = Prefs.of(this)

        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        listenerRegistered = true

        val filter = IntentFilter(VOLUME_CHANGED_ACTION)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(volumeReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(volumeReceiver, filter)
        }
        receiverRegistered = true

        postNotification()
        refreshBar()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (instance != null) refreshBar()   // re-place on rotation; hidden in landscape
    }

    override fun onUnbind(intent: Intent?): Boolean {
        teardown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        if (!::wm.isInitialized) return   // destroyed before ever connecting
        if (listenerRegistered) {
            prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
            listenerRegistered = false
        }
        if (receiverRegistered) {
            try { unregisterReceiver(volumeReceiver) } catch (e: IllegalArgumentException) {}
            receiverRegistered = false
        }
        removeBar()
        removeLabel()
        getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
    }

    // ---------------------------------------------------------------- screenshot

    /** Closes the notification shade, waits for the animation, then captures. */
    fun capture() {
        bar?.visibility = View.INVISIBLE   // keep the bar out of the image
        performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        handler.postDelayed({ takeShot() }, 800)
    }

    private fun restoreBar() {
        handler.post { bar?.visibility = View.VISIBLE }
    }

    private fun takeShot() {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                    val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    result.hardwareBuffer.close()
                    restoreBar()
                    if (bmp == null) toast("Screenshot failed") else Thread { save(bmp) }.start()
                }

                override fun onFailure(errorCode: Int) {
                    restoreBar()
                    toast("Screenshot failed (code $errorCode)")
                }
            })
    }

    private fun save(bmp: Bitmap) {
        val name = "QuickShot_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".png"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/QuickShot")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) { toast("Could not save image"); return }
        try {
            contentResolver.openOutputStream(uri)?.use {
                bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            toast("Saved to Gallery")
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            toast("Could not save image")
        }
    }

    private fun toast(msg: String) =
        handler.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show() }

    // ---------------------------------------------------------------- volume bar overlay

    /**
     * (Re)builds the overlay from current prefs. Uses TYPE_ACCESSIBILITY_OVERLAY, which an enabled
     * accessibility service may add without the "Display over other apps" permission.
     * Portrait only: the Note 10+ buttons move to the top edge in landscape.
     */
    private fun refreshBar() {
        removeBar()
        if (instance == null) return
        if (!prefs.getBoolean(Prefs.BAR_ON, true)) return
        if (resources.configuration.orientation != Configuration.ORIENTATION_PORTRAIT) return

        val d = resources.displayMetrics.density
        val screen = wm.currentWindowMetrics.bounds
        val lenDp = prefs.getInt(Prefs.BAR_LEN, Prefs.DEF_LEN).coerceIn(100, 200)
        val h = (lenDp * d).toInt()
        val w = (BAR_WIDTH_DP * d).toInt()
        val yPct = prefs.getInt(Prefs.BAR_Y, Prefs.DEF_Y).coerceIn(0, 100)
        val topPx = (screen.height() * yPct / 100f).toInt().coerceIn(0, (screen.height() - h).coerceAtLeast(0))

        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = topPx
            title = "QuickShotVolumeBar"
        }

        val v = VolumeBarView(this, audio) { text -> showLabel(text) }
        v.opacityPercent = prefs.getInt(Prefs.BAR_ALPHA, Prefs.DEF_ALPHA).coerceIn(5, 40)
        v.syncFromSystem()
        try {
            wm.addView(v, lp)
            bar = v
            barParams = lp
        } catch (e: Exception) {
            toast("Volume bar could not be shown")
        }
    }

    private fun removeBar() {
        bar?.let { try { wm.removeView(it) } catch (e: IllegalArgumentException) {} }
        bar = null
        barParams = null
    }

    /** Shows a percentage pill beside the bar while dragging; null = release, hide after a beat. */
    private fun showLabel(text: String?) {
        if (text == null) {
            handler.removeCallbacks(hideLabel)
            handler.postDelayed(hideLabel, 600)
            return
        }
        handler.removeCallbacks(hideLabel)
        val tv = labelView ?: createLabel() ?: return
        tv.text = text
    }

    private fun createLabel(): TextView? {
        val bp = barParams ?: return null
        val d = resources.displayMetrics.density
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = 20 * d
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = ((BAR_WIDTH_DP + 12) * d).toInt()
            y = bp.y + bp.height / 2 - (20 * d).toInt()
            title = "QuickShotVolumeLabel"
        }
        return try {
            wm.addView(tv, lp)
            labelView = tv
            tv
        } catch (e: Exception) {
            null
        }
    }

    private fun removeLabel() {
        labelView?.let { try { wm.removeView(it) } catch (e: IllegalArgumentException) {} }
        labelView = null
    }

    // ---------------------------------------------------------------- notification panel

    private fun postNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Quick capture", NotificationManager.IMPORTANCE_LOW)
        )
        val capturePi = PendingIntent.getBroadcast(
            this, 0, Intent(this, CaptureReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val togglePi = PendingIntent.getBroadcast(
            this, 1, Intent(this, CaptureReceiver::class.java).setAction(ACTION_TOGGLE_BAR),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val barOn = Prefs.isBarOn(this)

        val captureAction = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_screenshot), "Capture", capturePi
        ).build()
        val toggleAction = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_volume),
            if (barOn) "Hide volume bar" else "Show volume bar", togglePi
        ).build()

        val n = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_screenshot)
            .setContentTitle("QuickShot")
            .setContentText(if (barOn) "Volume bar: on" else "Volume bar: off")
            .setContentIntent(capturePi)
            .addAction(captureAction)
            .addAction(toggleAction)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .build()
        nm.notify(NOTIF_ID, n)
    }
}
