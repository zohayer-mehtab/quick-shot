package com.quickshot.app

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScreenshotService : AccessibilityService() {

    companion object {
        @Volatile var instance: ScreenshotService? = null
        private const val CHANNEL_ID = "quickshot_capture"
        private const val NOTIF_ID = 1
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        postNotification()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
        return super.onUnbind(intent)
    }

    /** Closes the notification shade, waits for the animation, then captures. */
    fun capture() {
        performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        handler.postDelayed({ takeShot() }, 800)
    }

    private fun takeShot() {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                    val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    result.hardwareBuffer.close()
                    if (bmp == null) toast("Screenshot failed") else Thread { save(bmp) }.start()
                }

                override fun onFailure(errorCode: Int) {
                    toast("Screenshot failed (code $errorCode)")
                }
            })
    }

    private fun save(bmp: Bitmap) {
        val name = "QuickShot_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".png"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/QuickShot")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) { toast("Could not save image"); return }
        try {
            contentResolver.openOutputStream(uri)?.use {
                bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            toast("Saved to Gallery")
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            toast("Could not save image")
        }
    }

    private fun toast(msg: String) =
        handler.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show() }

    private fun postNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Quick capture", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getBroadcast(
            this, 0, Intent(this, CaptureReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_screenshot), "Capture", pi
        ).build()
        val n = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_screenshot)
            .setContentTitle("QuickShot")
            .setContentText("Tap to take a screenshot")
            .setContentIntent(pi)
            .addAction(action)
            .setOngoing(true)
            .setShowWhen(false)
            .build()
        nm.notify(NOTIF_ID, n)
    }
}
