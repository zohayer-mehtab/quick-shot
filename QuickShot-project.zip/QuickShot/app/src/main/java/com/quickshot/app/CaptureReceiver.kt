package com.quickshot.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class CaptureReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ScreenshotService.ACTION_TOGGLE_BAR -> Prefs.toggleBar(context)
            else -> ScreenshotService.instance?.capture()
        }
    }
}
