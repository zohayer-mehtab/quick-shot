package com.quickshot.app

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile that shows/hides the on-screen volume bar. */
class VolumeBarTile : TileService() {

    override fun onStartListening() = render()

    override fun onClick() {
        if (ScreenshotService.instance == null) {
            openApp()   // service not enabled yet: send the user to the enable screen
            return
        }
        Prefs.toggleBar(this)
        render()
    }

    private fun render() {
        val on = ScreenshotService.instance != null && Prefs.isBarOn(this)
        qsTile?.apply {
            state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            label = "Volume bar"
            subtitle = if (on) "On" else "Off"
            updateTile()
        }
    }
}
