package com.quickshot.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var volInfo: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        volInfo = findViewById(R.id.volInfo)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        findViewById<Button>(R.id.btnEnable).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnCapture).setOnClickListener {
            val service = ScreenshotService.instance
            if (service == null) {
                Toast.makeText(this, "Enable the service first", Toast.LENGTH_SHORT).show()
            } else {
                moveTaskToBack(true)   // hide this app so it isn't in the shot
                service.capture()
            }
        }

        val prefs = Prefs.of(this)

        // Volume bar on/off (black & white styling)
        val sw = findViewById<Switch>(R.id.switchBar)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.BLACK, 0xFF9E9E9E.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(0x66000000, 0x33000000))
        sw.isChecked = Prefs.isBarOn(this)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.BAR_ON, checked).apply()
        }

        bindSeek(R.id.seekY, R.id.valY, Prefs.BAR_Y, Prefs.DEF_Y, offset = 0) { "$it% from top" }
        bindSeek(R.id.seekLen, R.id.valLen, Prefs.BAR_LEN, Prefs.DEF_LEN, offset = 100) { "$it dp" }
        bindSeek(R.id.seekAlpha, R.id.valAlpha, Prefs.BAR_ALPHA, Prefs.DEF_ALPHA, offset = 5) { "$it%" }
    }

    /** value = progress + offset; persisted live so the overlay updates while dragging. */
    private fun bindSeek(
        seekId: Int, valueId: Int, key: String, def: Int, offset: Int, fmt: (Int) -> String
    ) {
        val seek = findViewById<SeekBar>(seekId)
        val label = findViewById<TextView>(valueId)
        val prefs = Prefs.of(this)

        seek.progressTintList = ColorStateList.valueOf(Color.BLACK)
        seek.thumbTintList = ColorStateList.valueOf(Color.BLACK)
        seek.progressBackgroundTintList = ColorStateList.valueOf(0xFFD0D0D0.toInt())

        val current = prefs.getInt(key, def)
        seek.progress = (current - offset).coerceIn(0, seek.max)
        label.text = fmt(seek.progress + offset)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, progress: Int, fromUser: Boolean) {
                label.text = fmt(progress + offset)
                if (fromUser) prefs.edit().putInt(key, progress + offset).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar) = Unit
            override fun onStopTrackingTouch(s: SeekBar) = Unit
        })
    }

    override fun onResume() {
        super.onResume()
        val on = ScreenshotService.instance != null
        status.text = if (on) "●  Service active" else "○  Service not enabled"

        val audio = getSystemService(AudioManager::class.java)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val step = if (max > 0) (100f / max) else 0f
        volInfo.text = "Media volume · $max steps (~${step.roundToInt()}% each)"
    }
}
