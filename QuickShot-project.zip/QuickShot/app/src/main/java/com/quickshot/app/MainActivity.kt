package com.quickshot.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        findViewById<Button>(R.id.btnEnable).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnCapture).setOnClickListener {
            val service = ScreenshotService.instance
            if (service == null) {
                Toast.makeText(this, "Enable the service first", Toast.LENGTH_SHORT).show()
            } else {
                moveTaskToBack(true)   // hide this app so it isn't in the shot
                service.capture()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val on = ScreenshotService.instance != null
        status.text = if (on) "●  Service active" else "○  Service not enabled"
    }
}
